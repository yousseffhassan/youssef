
import time
import random
import sys

list = []


def print_pause(s):
    print(s)
    time.sleep(2)


def intro():   # start play:
    print_pause("You find yourself standing in an open field, "
                "filled with grass and yellow wildflowers. \n")
    print_pause("Rumor has it that a pirate is somewhere around here, "
                "and has been terrifying the nearby village. \n")
    print_pause("In front of you is a house.")
    print_pause("To your right is a dark cave.")
    print_pause("In your hand you hold your trusty "
                "(but not very effective) dagger. \n")


def play_again():   # to play again or exit the game:
    user_input = input("Would you like to play again? (y/n) \n").lower()
    if user_input == 'y':
        print_pause("Excellent! Restarting the game ... \n")
        choice()
    elif user_input == 'n':
        print_pause("Thanks for playing... Goodbye, until we meet again! \n")
        sys.exit()
    else:
        play_again()


def house():  # house1(place1):
    print_pause("The door open and out comes a ghost \n")
    fight_or_run = input("Would you like to (1) fight or (2) run away? \n")
    if fight_or_run == '1':
        print_pause("As the wicked fairie moves to attack, you unsheath your "
                    "new sword. \n")
        print_pause("The Sword of Ogoroth shines brightly in your hand as you "
                    "brace yourself for the attack. \n")
        print_pause("But the wicked fairie takes one look at your shiny new "
                    "toy and runs away! \n")
        print_pause("You have rid the town of the wicked fairie. You are"
                    "victorious! \n")
        play_again()
    elif fight_or_run == '2':
        print_pause("You run back into the field. Luckily, you don't seem "
                    "to have been followed. \n")
        choice()
    else:
        error_input()


def cave():  # cave(place2):
    if "magical sword" not in list:
        print_pause("You have found the magical Sword of Ogoroth! \n")
        print_pause("You discard your silly old dagger and take the sword "
                    "with you. \n")
        print_pause("You walk back out to the field. \n")
        print_pause("As the wicked fairie moves to attack, you unsheath your "
                    "new sword. \n")
        print_pause("You have rid the town of the wicked fairie. You are "
                    "victorious! \n")
        play_again()
        list.append("magical sword")

    else:
        print_pause("You've been here before, and gotten all the good "
                    "stuff. It's just an empty cave now. \n")
        print_pause("You walk back out to the field. \n")
        choice()


def house2():   # house2(place2):
    print_pause("You approach the door of the house. \n")
    print_pause("You are about to knock when the door opens and out steps a "
                "wicked fairie. \n")
    print_pause("Eep! This is the wicked fairie's house! \n")
    if "magical sword" in list:
        print_pause("As the wicked fairie moves to attack, you unsheath your "
                    "new sword. \n")
        print_pause("You have rid the town of the wicked fairie. You are "
                    "victorious! \n")
        play_again()
    else:
        print_pause("The wicked fairie attacks you! \n")
        print_pause("You've lost! \n")
        play_again()


def randomfunc():
    list2 = [house(),house2()]
    random.choice(list2)


def choice():
    intro()
    print_pause("Enter 1 to knock on the door of the house \n")
    print_pause("Enter 2 to peer into the cave \n")
    user_choice = input("What do you choose?(1/2) \n")
    if user_choice == '1':
        randomfunc()
    elif user_choice == '2':
        cave()
    else:
        error_input()


def error_input():
    user_choice = input("(Please enter 1 or 2) \n")
    while True:
        if user_choice == '1':
            choice()
        elif user_choice == '2':
            choice()
        else:
            user_choice = input("(Please enter 1 or 2) \n")


def error_answer():
    user_input = input("Please enter y or n:").lower()
    while True:
        while user_input != 'y' or user_input != 'n':
            user_input = input("Please enter y or n:").lower()


def game():
    choice()
game()
